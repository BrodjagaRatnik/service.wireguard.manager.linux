""" ./resources/lib/vpn_utils.py """
import kodi_env
import json
import os
import subprocess
import time
import datetime
from logger import log_message
from vpn_config import PROVIDER_MAP

try:
    import xbmcgui
    HAS_KODI = True
except ImportError:
    HAS_KODI = False


def get_addon_path():
    return kodi_env.ADDON_DIR


def get_dynamic_prefixes():
    prefixes = ["wg", "vpn", "tun"]
    try:
        for key in PROVIDER_MAP:
            if "prefix" in PROVIDER_MAP[key]:
                clean_prefix = PROVIDER_MAP[key]["prefix"].replace("_", "")
                if clean_prefix not in prefixes:
                    prefixes.append(clean_prefix)
    except Exception:
        pass
    return prefixes


def is_interface_active(interface_name=None):
    try:
        if not os.path.exists("/proc/net/dev"):
            return False

        with open("/proc/net/dev", "r") as f:
            lines = f.readlines()

        if interface_name:
            return any(line.split(":")[0].strip() == interface_name for line in lines if ":" in line)

        prefixes = get_dynamic_prefixes()
        for line in lines:
            if ":" in line:
                iface = line.split(":")[0].strip().lower()
                if any(x in iface for x in prefixes):
                    return True
        return False
    except Exception:
        return False


def get_active_interface():
    for attempt in range(3):
        try:
            out = subprocess.check_output(
                ["ip", "route", "show", "default"],
                text=True,
                stderr=subprocess.DEVNULL
            )
            interfaces = []
            for line in out.splitlines():
                parts = line.split()
                if "dev" in parts:
                    dev_idx = parts.index("dev") + 1
                    if dev_idx < len(parts):
                        interfaces.append(parts[dev_idx].strip())

            prefixes = get_dynamic_prefixes()
            for iface in interfaces:
                iface_lower = iface.lower()
                if any(x in iface_lower for x in prefixes):
                    return str(iface)

            virtual_interfaces = [
                i for i in interfaces
                if not any(phys in i.lower() for phys in ["enp", "eth", "wlan", "wlp", "lo"])
            ]
            if virtual_interfaces:
                return str(virtual_interfaces[0])

            if interfaces:
                return str(interfaces[0])

        except Exception as e:
            log_message(f"VPN_Utils: Interface lookup error: {e}", 3)
            return None

        if attempt < 2:
            time.sleep(0.25)

    return None


def check_interface_status():
    try:
        if not os.path.exists("/proc/net/dev"):
            return False, False
        with open("/proc/net/dev", "r") as f:
            lines = f.readlines()

        eth = False
        wifi = False
        prefixes = get_dynamic_prefixes()
        prefixes.extend(["wireguard", "lo"])

        for line in lines:
            if ":" in line:
                iface = line.split(":")[0].strip()
                if not any(x in iface.lower() for x in prefixes):
                    if iface.startswith(("eth", "en")):
                        eth = True
                    elif iface.startswith(("wlan", "wl")):
                        wifi = True
        return eth, wifi
    except Exception as e:
        log_message(f"VPN_Utils: Interface status validation check failure: {e}", 3)
        return False, False


def fetch_vpn_metadata(interface_name):
    t_stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    if interface_name:
        try:
            ping_res = subprocess.run(
                ["ping", "-c", "1", "-W", "2", "-I", interface_name, "1.1.1.1"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            if ping_res.returncode != 0:
                log_message(f"VPN_Utils: Data path verification failed via ICMP on {interface_name}", 2)
                if HAS_KODI:
                    try:
                        title = "[B][COLOR FFFF0000]VPN Connection Error[/COLOR][/B]"
                        msg = "[COLOR FFE6E6FA]Data path blocked. Check connection.[/COLOR]"
                        xbmcgui.Dialog().ok(title, msg)
                    except Exception:
                        pass
                return None, None
        except Exception:
            pass

    cmd_io = ["curl", "-s", "--connect-timeout", "4.0", "--max-time", "6.0"]
    if interface_name:
        cmd_io.extend(["--interface", interface_name])
    cmd_io.append("https://ipinfo.io")

    try:
        res = subprocess.check_output(cmd_io, text=True)
        if res and res.strip():
            data = json.loads(res)
            if "ip" in data:
                log_message(f"VPN_Utils: Ipinfo provider selected at {t_stamp}", 0)
                return data.get("ip", "Unknown"), data.get("country", "??")
    except Exception:
        pass

    cmd_co = ["curl", "-s", "--connect-timeout", "4.0", "--max-time", "8.0"]
    if interface_name:
        cmd_co.extend(["--interface", interface_name])
    cmd_co.append("https://ipapi.co")

    try:
        res = subprocess.check_output(cmd_co, text=True)
        if res and res.strip():
            data = json.loads(res)
            if "ip" in data:
                log_message(f"VPN_Utils: Ipapi provider selected at {t_stamp}", 0)
                return data.get("ip", "Unknown"), data.get("country_code", "??")
    except Exception as e:
        log_message(f"VPN_Utils: All metadata fallbacks failed at {t_stamp}: {e}", 2)

    return "Unknown", "??"


def setup_pia_handshake(sid, provider_data, addon_obj, has_kodi):
    from providers.pia_utils import setup_pia_handshake as resolve_pia_handshake
    return resolve_pia_handshake(sid, provider_data, addon_obj, has_kodi)
