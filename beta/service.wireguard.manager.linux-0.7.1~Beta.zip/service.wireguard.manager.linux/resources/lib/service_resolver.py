""" ./resources/lib/service_resolver.py """
import os
import sys
import kodi_env
from logger import log_message

ADDON_DIR = kodi_env.ADDON_DIR
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

CONFIG_DIR = os.path.expanduser("~/.config/wireguard/")


def _clean(text):
    return (
        str(text).lower()
        .replace('nordvpn', '')
        .replace('mullvad', '')
        .replace('custom', '')
        .replace('pia', '')
        .replace('_', '')
        .replace('-', '')
        .replace(' ', '')
        .strip()
    )


def resolve_service_id(addon, name):
    try:
        if not name:
            return None

        clean_target = _clean(name)
        if not clean_target:
            return None

        if not os.path.exists(CONFIG_DIR):
            return None

        best_match = None
        best_match_len = -1

        for filename in os.listdir(CONFIG_DIR):
            if not filename.lower().endswith((".conf", ".config")):
                continue

            profile_id = filename.replace(".conf", "").replace(".config", "")
            file_path = os.path.join(CONFIG_DIR, filename)

            friendly_title = None
            try:
                with open(file_path, "r", encoding="utf-8") as cf:
                    for line in cf:
                        if line.startswith("# FriendlyName ="):
                            friendly_title = line.split("=", 1)[-1].strip()
                            break
            except Exception:
                continue

            candidate_label = friendly_title if friendly_title else profile_id
            clean_candidate = _clean(candidate_label)

            if clean_target == clean_candidate:
                return profile_id

            if clean_candidate and (clean_candidate in clean_target or clean_target in clean_candidate):
                if len(clean_candidate) > best_match_len:
                    best_match = profile_id
                    best_match_len = len(clean_candidate)

        return best_match

    except Exception as e:
        log_message(f"Service Resolver: lookup error for {name}: {e}", 3)
        return None
