""" ./resources/lib/providers/custom.py """
import os
import subprocess
from logger import log_message


def update(source_path, target_config_dir):
    try:
        if not os.path.exists(source_path):
            log_message(f"Custom Compiler: Source file not found: {source_path}", 3)
            return False

        if not os.path.exists(target_config_dir):
            os.makedirs(target_config_dir, exist_ok=True)

        config_data = {}
        with open(source_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("["):
                    continue
                if "=" in line:
                    key, val = line.split("=", 1)
                    key = key.strip().lower().replace("wireguard.", "")
                    val = val.strip()
                    config_data[key] = val

        private_key = config_data.get("privatekey")
        address = config_data.get("address")
        dns_str = config_data.get("dns")
        mtu_val = config_data.get("mtu", "1380")
        public_key = config_data.get("publickey")

        host_ip = config_data.get("host") or config_data.get("endpoint")
        if host_ip and ":" in host_ip:
            host_parts = host_ip.split(":")
            host_ip = host_parts[0].strip()
            endpoint_port = host_parts[1].strip()
        else:
            endpoint_port = config_data.get("endpointport", "51820")

        keepalive = config_data.get("persistentkeepalive", "25")

        if not all([private_key, address, dns_str, public_key, host_ip]):
            log_message("Custom Compiler: Missing vital parameters inside configuration profile.", 3)
            return False

        raw_base = os.path.basename(source_path).lower().replace(".config", "").replace(".conf", "")
        clean_words = raw_base.replace("custom_", "").replace("_", " ").replace("-", " ")
        pretty_name = f"Custom {clean_words.strip().title()}"

        clean_addr = str(address).split("/")[0].strip()
        b_name = raw_base if raw_base.startswith("custom_") else f"custom_{raw_base}"
        b_name = b_name.replace(" ", "_")
        if len(b_name) > 15:
            b_name = b_name[:15]

        dest_filename = f"{b_name}.conf"
        file_path = os.path.join(target_config_dir, dest_filename)

        dest_lines = [
            f"# FriendlyName = {pretty_name}",
            "[Interface]",
            f"PrivateKey = {private_key}",
            f"Address = {clean_addr}/32",
            f"DNS = {dns_str}",
            f"MTU = {mtu_val}",
            "",
            "[Peer]",
            f"PublicKey = {public_key}",
            f"Endpoint = {host_ip}:{endpoint_port}",
            "AllowedIPs = 0.0.0.0/0, ::/0",
            f"PersistentKeepalive = {keepalive}"
        ]

        with open(file_path, "w", encoding="utf-8") as target_file:
            target_file.write("\n".join(dest_lines) + "\n")

        subprocess.run(
            ["nmcli", "connection", "delete", "id", b_name],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False
        )

        import_res = subprocess.run(
            ["nmcli", "connection", "import", "type", "wireguard", "file", str(file_path)],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, check=False
        )

        if import_res.returncode != 0:
            log_message(f"Custom Compiler: nmcli import failed: {import_res.stderr.strip()}", 3)
            return False

        subprocess.run(
            ["nmcli", "connection", "modify", b_name,
             "ipv4.dns-priority", "100",
             "ipv6.dns-priority", "100",
             "wireguard.ip4-auto-default-route", "false"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False
        )

        subprocess.run(
            ["nmcli", "connection", "modify", pretty_name,
             "ipv4.dns-priority", "100",
             "ipv6.dns-priority", "100",
             "wireguard.ip4-auto-default-route", "false"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False
        )

        log_message(f"Custom Compiler: Profile {pretty_name} ({b_name}) registered successfully.", 1)
        return True

    except Exception as e:
        log_message(f"Custom Compiler: Runtime failure parsing configuration module: {e}", 3)
        return False
